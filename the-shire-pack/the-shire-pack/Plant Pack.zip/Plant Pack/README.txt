Thank you for downloading my item pack! 

ABOUT
Each item pack comes with individual files with x1, x2, and x4 resolution sizes.
Packs also include a spritesheet with all items. 
All files are pngs. 
Each pack includes 3 color palettes: cozy, neon, and pastel.
The name and size guide will include a picture of all of the items in the pack,
the name of each item, and the exact size of the original sprite.

LICENSE
These assets may be used in both non-commercial and commercial projects, 
excluding those relating to or containing non-fungible tokens ("NFT") 
or blockchain-related projects. 
It may not be used in conjunction with generative artificial intelligence projects 
or machine learning projects. You may modify it to suit your needs. 
You may not redistribute or resell it. 
Credit is not mandatory but I would appreciate it if you did!

You can :
Use these assets for personal and commercial projects.
Adapt and modify these assets, their palette and their layout to match your project and needs.

You can not :
Claim these assets as yours.
Distribute or sell those assets, even when modified.
Use the assets for a NFT/metaverse/AI project.

WHERE TO FIND MORE PIXELED PUMPKINS ART:
https://ko-fi.com/pixeledpumpkins
https://pixeledpumpkins.itch.io/
https://www.twitch.tv/pixeledpumpkins
